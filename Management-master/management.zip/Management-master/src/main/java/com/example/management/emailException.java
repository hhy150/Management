package com.example.management;

public class emailException extends Exception {
    public emailException(String msg){
        super(msg);
    }
}
