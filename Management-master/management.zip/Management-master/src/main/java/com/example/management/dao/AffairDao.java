package com.example.management.dao;


import com.example.management.entity.SendAffairParam;
import com.example.management.entity.Student;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface AffairDao {
    List<Student> getMemberByParam(SendAffairParam sendAffairParam);

    List<Student> getAllMember();

    List<Student> getMemberByName(String memberName);

    List<Student> getMemberByDeptId(String dept_id);


}
