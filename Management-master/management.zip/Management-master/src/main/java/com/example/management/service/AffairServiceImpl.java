package com.example.management.service;

import com.example.management.dao.AffairDao;
import com.example.management.emailException;
import com.example.management.entity.Affair;
import com.example.management.entity.SendAffairParam;
import com.example.management.entity.Student;

import com.example.management.util.MailUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AffairServiceImpl implements AffairService {

    @Autowired
    private AffairDao affairDao;

    private static final String SUCCESS = "派发成功";


    @Override
    public String sendAffair(String type, SendAffairParam sendAffairParam, Affair affair) {
        String result = null;
        List<Student> selectedStudents = null;

        switch (type){
            case SendAffairParam.SEND_ALL:
                selectedStudents = affairDao.getAllMember();
                break;
            case SendAffairParam.SEND_CONDITIONAL:
                selectedStudents = affairDao.getMemberByParam(sendAffairParam);
                break;
            case SendAffairParam.SEND_PERSONAL:
                selectedStudents = affairDao.getMemberByParam(sendAffairParam);
                break;
            case SendAffairParam.SEND_RANDOMLY:
                break;
            default:
                return "send affair failed: you didn't chose any type";
        }
        if (selectedStudents == null){
            return "no members were selected";
        }
        try {
            result = sendAffairCore(sendAffairParam, selectedStudents,affair);
        } catch (emailException e) {
            e.printStackTrace();
        }
        return result;
    }

    private String sendAffairCore(SendAffairParam sendAffairParam, List<Student> members, Affair affair) throws emailException {
        if (members.isEmpty()){
            return "派发任务失败";
        }
        MailUtil mailUtil = new MailUtil();
        String result = mailUtil.sendMail(sendAffairParam.getTemplateType(), sendAffairParam.getSenderName(), affair.getTitle(), affair.getEndTime(), members);
        if (!result.equals(SUCCESS)){
            return "派发任务失败：util未返回预期值";
        }else {
            return "派发任务成功";
        }

    }
}
