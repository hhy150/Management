package com.example.management.service;


import com.example.management.entity.Affair;
import com.example.management.entity.SendAffairParam;

public interface AffairService {
    String sendAffair(String type, SendAffairParam sendAffairParam, Affair affair);

}
