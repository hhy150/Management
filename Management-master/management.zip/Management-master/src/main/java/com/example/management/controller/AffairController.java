package com.example.management.controller;

import com.example.management.entity.Affair;
import com.example.management.entity.Club;
import com.example.management.entity.Department;
import com.example.management.entity.SendAffairParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AffairController {

    private Affair send(Department department,Affair affair){
        return null;
    }

    private Affair send(Club club,Affair affair){
        return null;
    }
    private SendAffairParam buildSendAffairParam(Club club,Affair affair,String templateType,String memCondition){
        SendAffairParam sendAffairParam = new SendAffairParam();
        sendAffairParam.setSenderId(club.getId().toString());
        sendAffairParam.setName(club.getName());
        sendAffairParam.setMemCondition(memCondition);
        sendAffairParam.setTemplateType(templateType);
        return sendAffairParam;
    }
    private SendAffairParam buildSendAffairParam(Department department,Affair affair,String templateType,String memCondition){
        SendAffairParam sendAffairParam = new SendAffairParam();
        sendAffairParam.setSenderId(department.getId().toString());
        sendAffairParam.setName(department.getName());
        sendAffairParam.setMemCondition(memCondition);
        sendAffairParam.setTemplateType(templateType);
        return sendAffairParam;
    }
}
